# 环境与命令

## 十三 环境准备与运行命令

### 首次开工必须发现环境
T001 记录实际 Cocos 小版本、编辑器位置、Node 版本、包管理器、项目目录、物理后端、可用构建目标和当前 Git 状态。新项目通过该版本编辑器生成；已有项目先读 package.json、tsconfig、设置和 meta，不直接重建覆盖。

Cocos 资源脚本依赖引擎环境，不能把普通 Node 执行 TypeScript 的成功当作场景能运行。Creator 的构建参数、可用扩展与 TapTap 接入方式需按实际版本核对后记录。[C5][C6][T2]

### 建立实际存在的命令契约
| 约定命令 | T001 完成后应做什么 |
| --- | --- |
| npm run check:config | 校验配置结构 引用和范围 |
| npm run test:unit | 执行无 cc 依赖的规则测试 |
| npm run typecheck | 执行经实际工程确认可用的类型检查 |
| npm run verify | 串行运行上述三个检查并保留失败码 |
| npm run build:web | 调用已验证的 Creator 构建入口 |

这些是待实现的目标命令，不是本资料包已经提供的脚本。若现有工程使用 pnpm 或其他工具，沿用现有工具并更新全部文档。不得遇到缺少命令就伪造成功输出或删除检查。

### 证据与接续
每次验证记录命令、工作目录、退出码、引擎和配置版本、源码版本以及日志路径。运行验收再补设备、场景、操作步骤和录屏。没有可用 WebGL 时把运行验证标为 BLOCKED，静态检查可正常继续。

### 人工最小准备清单
安装并打开记录的小版本编辑器，建立或打开 2D 工程，确认 Box2D 后端，导入脚本后打开 PhysicsLab 运行。微信与 TapTap 的 AppID、证书和账户能力在对应渠道任务处理，不写进共享配置或提示词。

自动写代码不等于自动获得所有渠道凭据，也不等于已经在手机上跑过；状态文件必须区分代码完成、运行完成和渠道验证完成。

## T001 需要填写
enginePatch: 未检测
creatorExecutable: 未检测
nodeVersion: 未检测
packageManager: 未检测
projectRoot: 未创建
physicsBackend: 目标 Box2D 2D 未运行验证
commands: 目标命令尚未实现
editorImportResult: 未执行
webBuildResult: 未执行
webglRuntimeResult: 未执行
currentSourceRevision: 未创建

实际命令必须在当前工程确认后替换此节，不复制其他电脑的绝对路径。
