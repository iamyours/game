# 风暴弓手 Codex 开发包

V2.0，2026 年 11 月 7 日。横屏实时物理对射。

本包是开发文档、任务卡、配置种子和验收模板，不是可运行的 Cocos 工程。没有已经实现的 npm 脚本、游戏源码或已通过的游戏测试。

## 第一步
在目标 Cocos 工程根目录放置 AGENTS.md、docs、tasks、configs、templates 和 evidence。已有同名文件先比较合并，保留现有规则。完整 Word 是审阅快照，日常开发维护仓库 Markdown、配置和状态文件。

## 给 Codex 的第一句话
读取 AGENTS.md、docs/STATUS.md、docs/PLAN.md 和 tasks/T001.md，检查当前工程，按 T001 开始实现并验证，不只返回计划。保持横屏、真实物理受击与短关卡方向。缺少运行环境时完成独立工作，写明阻塞，不伪造测试结果。

## 文件索引
- 风暴弓手Codex开发文档.md：完整说明。
- AGENTS.md：稳定的仓库约束。
- docs/PRD.md：玩法、操作、物理反馈、关卡与资源规格。
- docs/ARCHITECTURE.md：工程结构、数据和物理步顺序。
- docs/PLAN.md：里程碑、依赖、估算。
- docs/STATUS.md：真实状态和下一任务。
- docs/PROMPTS.md：可直接发送的开工、接续和修复提示词。
- docs/ACCEPTANCE.md、docs/QA.md：手感验收与运行用例。
- docs/ENVIRONMENT.md：环境发现和待实现的命令契约。
- docs/DECISIONS.md：当前设计取舍。
- docs/PLATFORM.md：性能与渠道边界。
- docs/ART_SPEC.md、docs/FAQ.md、docs/SOURCES.md：美术、问答与资料。
- tasks/T001.md 至 T018.md：18 张详细任务卡。
- tasks.csv、qa_cases.csv：可填写进度与结果。
- configs/*.seed.json：首轮配置，需要引擎标定后转成运行配置。
- templates：状态、缺陷、证据和手感报告模板。
- evidence/README.md：后续日志与录屏的存放约定。

## 当前进度
T001 至 T018 均未开始。自动化规则测试、Cocos 运行、性能与渠道真机均未执行。资料包只对文档、任务依赖和配置引用做静态检查。
