# 风暴弓手技术架构

## 十一 工程结构与模块职责

### 保持一套生产物理
生产物理统一使用 Cocos Box2D 2D，不另建一套浏览器物理代码代替引擎验收。可把公式、结算和状态转换写成无引擎依赖的 TypeScript，供命令行测试；运行中的刚体、碰撞和手感在 Cocos 内验证。

| 目录或模块 | 负责内容 |
| --- | --- |
| assets/scripts/core | 事件 生命周期 时间与配置加载 |
| assets/scripts/domain | 伤害 冷却 解锁 结算等纯逻辑 |
| assets/scripts/input | 多触点 瞄准 取消和键鼠适配 |
| assets/scripts/physics | 单位适配 角色工厂 姿态 关节 |
| assets/scripts/combat | 弓 箭 命中队列 装甲 掉落 |
| assets/scripts/level | 敌人 波次 补给 胜败 |
| assets/scripts/presentation | 相机 音效 粒子和 UI 订阅 |
| assets/scripts/platform | Web 微信 TapTap 存储与生命周期 |
| assets/scenes | Boot PhysicsLab Battle |
| tests scripts docs | 纯逻辑测试 工具和开发记录 |

### 引擎边界
PhysicsAdapter 统一长度、速度、角度、冲量和重力的输入输出。RagdollFactory 创建身体与铰链；PoseController 只通过力、扭矩或马达控制；AimController 生成手臂目标；ProjectileSystem 管理飞行；HitResolver 统一结算。

EquipmentSystem 负责弓盔附着、脱落与回收；WaveDirector 生成敌人并判断清波；RunSession 管理胜败和唯一结算；Presentation 只读取事件。任何 UI 节点都不直接给敌人扣血。

### 编辑器与脚本协作
Boot 场景保持精简，挂一个入口组件。PhysicsLab 的平台、骨架和测试箭优先由工厂程序生成，便于 Codex 反复修改和复现。正式素材可逐步使用预制体，但必须由编辑器导入并保留 meta 文件；不能随意伪造 UUID 或覆盖整个工程配置。

## 十二 数据契约与物理顺序

### 关键数据
CombatConfig 保存射击、生命体力、部位倍率和装备阈值。RigDefinition 保存部位尺寸质量、锚点和逻辑限位。LevelDefinition 保存米制平台、出生点、敌人和波次。ActorState 保存生命、姿态、武器和部位受创。ShotState 保存 shotId、所有者、阵营、飞行和结算状态。

HitEvent 至少包含 stepId、shotId、attackerId、targetId、partId、worldPoint、normal、incomingVelocity、damage、armorDamage 和 reactionType。接触对象只在回调时读取，事件中使用数值快照，不保留即将失效的引擎接触引用。

### 一次物理步的处理
1. 采样输入并更新射击意图，不直接在输入事件里生成多支箭。
2. 在物理更新前应用姿态控制、瞄准目标和本步合法发射。
3. 引擎完成固定步模拟，收集接触与扫掠候选。
4. 物理步后按箭排序去重，执行装甲、伤害、局部冲量和受创。
5. 统一执行死亡、掉弓、掉盔、插箭和安全回收，再发出表现事件。
6. 结算胜败和波次；UI 与相机读取已完成的数据。

具体前后步挂接点在锁定小版本里验证。不能在渲染帧和物理步各运行一次同一套冷却或伤害。

### 姿态与瞄准
先选择关节马达作为主要角度驱动，目标由关节当前角误差计算，驱动速度和最大扭矩限幅。需要整身平衡时再添加受限的躯干扭矩；不能对同一自由度叠加两套强回正控制。

瞄准使用世界方向，依据当前肩部位置生成持弓手和拉弦手目标，再做两段 IK。可达范围内稍留肘部弯曲，防止完全伸直导致解翻转。倒地后仍从真实 BowSocket 发射，出生点前方受阻时取消本次发射，不从躯干内部穿出。

受击权重按局部关节组衰减并恢复。参数与质量、惯量有关，配置中的初值不得未经运行标定直接当成最终物理常数。
